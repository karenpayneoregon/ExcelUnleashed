﻿namespace ConcreteLibrary
{
    public class Customer
    {
        public string CompanyName { get; set; }
        public string ContactName { get; set; }
        public string ContactTitle { get; set; }
    }
}
